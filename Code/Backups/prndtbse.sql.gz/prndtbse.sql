-- MySQL dump 10.13  Distrib 5.6.33, for Linux (x86_64)
--
-- Host: localhost    Database: prndtbse
-- ------------------------------------------------------
-- Server version	5.6.33-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Contnt_categories`
--

DROP TABLE IF EXISTS `Contnt_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Contnt_categories` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `text` varchar(350) DEFAULT NULL,
  `paid_type` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Contnt_categories`
--

LOCK TABLES `Contnt_categories` WRITE;
/*!40000 ALTER TABLE `Contnt_categories` DISABLE KEYS */;
INSERT INTO `Contnt_categories` (`id`, `name`, `category_id`, `text`, `paid_type`) VALUES (1,'food',1,'Food',NULL),(2,'housing',2,'Housing',NULL),(3,'medical',3,'Medical',NULL),(4,'legal',4,'Legal',NULL),(5,'study',5,'Study',NULL),(6,'jobs',6,'Jobs',NULL),(7,'organizations',7,'Organizations',NULL),(8,'volunteers',8,'Volunteers',NULL);
/*!40000 ALTER TABLE `Contnt_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Contnt_food`
--

DROP TABLE IF EXISTS `Contnt_food`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Contnt_food` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) DEFAULT NULL,
  `category` varchar(25) DEFAULT NULL,
  `sub_category` varchar(500) DEFAULT NULL COMMENT 'divided by commas',
  `paid_type` int(11) DEFAULT NULL,
  `area` varchar(100) DEFAULT NULL,
  `availability` int(11) DEFAULT NULL,
  `fee` varchar(25) NOT NULL DEFAULT 'N.A.',
  `text1` varchar(76) DEFAULT NULL,
  `text2` text,
  `overide_image` varchar(150) DEFAULT NULL,
  `rating` int(16) DEFAULT NULL,
  `link` varchar(500) DEFAULT NULL,
  `organization` varchar(500) DEFAULT NULL,
  `organization_venue_address` varchar(500) DEFAULT NULL,
  `womenonly` tinyint(4) DEFAULT '0',
  `menonly` tinyint(4) DEFAULT '0',
  `children` tinyint(4) DEFAULT '0',
  `pets` tinyint(4) DEFAULT '0',
  `soupkitchen` tinyint(4) NOT NULL DEFAULT '0',
  `tafel` tinyint(4) NOT NULL DEFAULT '0',
  `free_givaway` tinyint(4) NOT NULL DEFAULT '0',
  `churchgive` tinyint(4) NOT NULL DEFAULT '0',
  `foodtour` tinyint(4) NOT NULL DEFAULT '0',
  `smoking` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`link`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Contnt_food`
--

LOCK TABLES `Contnt_food` WRITE;
/*!40000 ALTER TABLE `Contnt_food` DISABLE KEYS */;
INSERT INTO `Contnt_food` (`id`, `name`, `category`, `sub_category`, `paid_type`, `area`, `availability`, `fee`, `text1`, `text2`, `overide_image`, `rating`, `link`, `organization`, `organization_venue_address`, `womenonly`, `menonly`, `children`, `pets`, `soupkitchen`, `tafel`, `free_givaway`, `churchgive`, `foodtour`, `smoking`) VALUES (1,'Food test 1','food',NULL,0,'0',100,'N.A.','This is a food test.This is a food test.This is a food test.This is a food t','This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.',NULL,3,NULL,'1','1',1,0,0,0,0,0,1,1,0,0),(2,'Food Test 2','food',NULL,0,'0',100,'N.A.','This is a food test.This is a food test.This is a food test.This is a food t','This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.This is a food test.',NULL,3,NULL,'1','1',1,0,0,0,0,0,1,1,0,0);
/*!40000 ALTER TABLE `Contnt_food` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Contnt_housing`
--

DROP TABLE IF EXISTS `Contnt_housing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Contnt_housing` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `name` varchar(18) CHARACTER SET latin1 COLLATE latin1_german1_ci DEFAULT NULL,
  `category` varchar(25) DEFAULT NULL,
  `sub_category` varchar(500) DEFAULT NULL COMMENT 'divided by commas',
  `paid_type` int(11) DEFAULT NULL,
  `to_` int(11) DEFAULT NULL,
  `tc` int(11) DEFAULT NULL,
  `days_open` varchar(16) DEFAULT NULL,
  `area` varchar(100) DEFAULT NULL,
  `availability` int(11) DEFAULT NULL,
  `fee` varchar(25) NOT NULL DEFAULT 'N.A.',
  `text1` varchar(76) DEFAULT 'N.A.',
  `text1_Deutsch` varchar(76) DEFAULT NULL,
  `text2` varchar(400) DEFAULT 'N.A.',
  `overide_image` varchar(150) DEFAULT NULL,
  `rating` int(16) DEFAULT NULL,
  `link` varchar(500) DEFAULT NULL,
  `organization` varchar(500) DEFAULT NULL,
  `organization_venue_address` varchar(500) DEFAULT NULL,
  `is_` varchar(150) DEFAULT NULL COMMENT 'divided by commas',
  `allows` varchar(150) DEFAULT NULL COMMENT 'divided by commas',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`link`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Contnt_housing`
--

LOCK TABLES `Contnt_housing` WRITE;
/*!40000 ALTER TABLE `Contnt_housing` DISABLE KEYS */;
INSERT INTO `Contnt_housing` (`id`, `name`, `category`, `sub_category`, `paid_type`, `to_`, `tc`, `days_open`, `area`, `availability`, `fee`, `text1`, `text1_Deutsch`, `text2`, `overide_image`, `rating`, `link`, `organization`, `organization_venue_address`, `is_`, `allows`) VALUES (1,'Test Venue','housing',NULL,0,7,22,'5,6','0',25,'N.A.','This is a text of 76 characters only, description does not allow any more ch',NULL,'This is a description. Descriptions are nice though this one only allows 600 characters, oh bummer. Bet you what. you like this description. anyways I\'m testing the 600 characters. Its not to easy but i have to count this. One min. ok I don\'t think it is as many as I think so I will keep writing, I think I will use this text to test all of the db entries. Anyways, life\'s cool, ugly weather today.T',NULL,3,'www.google.com','1','1','Shelters,Hostels','[Women] only'),(2,'Caritas','housing',NULL,0,4,5,NULL,'0',65,'N.A.','blablablabla.',NULL,'This is a description. Descriptions are nice though this one only allows 600 characters, oh bummer. Bet you what. you like this description. anyways I\'m testing the 600 characters. Its not to easy but i have to count this. One min. ok I don\'t think it is as many as I think so I will keep writing, I think I will use this text to test all of the db entries. Anyways, life\'s cool, ugly weather today.T',NULL,5,'www.caritas.com','1','2','Shelters','[Men] only'),(3,'Test Venue 3','housing',NULL,0,NULL,NULL,NULL,'0',99,'N.A.','N.A.',NULL,'N.A.',NULL,NULL,NULL,'1','1',NULL,NULL),(4,'huguz','housing',NULL,2,NULL,NULL,NULL,'0',5,'N.A.','N.A.',NULL,'N.A.',NULL,NULL,NULL,'1','3',NULL,NULL),(5,'tfzt','food',NULL,0,NULL,NULL,NULL,'0',0,'N.A.',',mlökmlö',NULL,NULL,NULL,NULL,NULL,'1','1',NULL,NULL),(6,'WHAT??','housing',NULL,0,NULL,NULL,NULL,'3',32,'N.A.','EHHH?',NULL,NULL,NULL,NULL,NULL,'1','1',NULL,NULL),(7,'SJFKSDJF','housing',NULL,0,4,5,NULL,'5',54,'N.A.','fsfs',NULL,NULL,NULL,NULL,NULL,'2','1',NULL,NULL),(8,'Fo9odland','food',NULL,0,NULL,NULL,NULL,'0',100,'N.A.','dayum bro, dat some food.',NULL,'text 2?',NULL,3,NULL,'1','1','0','0');
/*!40000 ALTER TABLE `Contnt_housing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Contnt_medical`
--

DROP TABLE IF EXISTS `Contnt_medical`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Contnt_medical` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) DEFAULT NULL,
  `category` varchar(25) DEFAULT NULL,
  `sub_category` varchar(500) DEFAULT NULL COMMENT 'divided by commas',
  `paid_type` int(11) DEFAULT NULL,
  `area` varchar(100) DEFAULT NULL,
  `availability` int(11) DEFAULT NULL,
  `fee` varchar(25) NOT NULL DEFAULT 'N.A.',
  `text1` varchar(76) DEFAULT NULL,
  `text2` text,
  `overide_image` varchar(150) DEFAULT NULL,
  `rating` int(16) DEFAULT NULL,
  `link` varchar(500) DEFAULT NULL,
  `organization` varchar(500) DEFAULT NULL,
  `organization_venue_address` varchar(500) DEFAULT NULL,
  `womenonly` tinyint(4) DEFAULT '0',
  `menonly` tinyint(4) DEFAULT '0',
  `children` tinyint(4) DEFAULT '0',
  `pets` tinyint(4) DEFAULT '0',
  `soupkitchen` tinyint(4) NOT NULL DEFAULT '0',
  `tafel` tinyint(4) NOT NULL DEFAULT '0',
  `free_givaway` tinyint(4) NOT NULL DEFAULT '0',
  `churchgive` tinyint(4) NOT NULL DEFAULT '0',
  `foodtour` tinyint(4) NOT NULL DEFAULT '0',
  `smoking` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`link`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Contnt_medical`
--

LOCK TABLES `Contnt_medical` WRITE;
/*!40000 ALTER TABLE `Contnt_medical` DISABLE KEYS */;
INSERT INTO `Contnt_medical` (`id`, `name`, `category`, `sub_category`, `paid_type`, `area`, `availability`, `fee`, `text1`, `text2`, `overide_image`, `rating`, `link`, `organization`, `organization_venue_address`, `womenonly`, `menonly`, `children`, `pets`, `soupkitchen`, `tafel`, `free_givaway`, `churchgive`, `foodtour`, `smoking`) VALUES (1,'Medical Test','medical',NULL,0,'0',100,'N.A.','This is a test medical postingThis is a test medical postingThis is a test m','This is a test medical postingThis is a test medical postingThis is a test medical postingThis is a test medical postingThis is a test medical postingThis is a test medical postingThis is a test medical postingThis is a test medical postingThis is a test medical postingThis is a test medical postingThis is a test medical postingThis is a test medical postingThis is a test medical postingThis is a test medical posting',NULL,100,'www.google.com','1','1',0,0,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `Contnt_medical` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Lang_Deutsch`
--

DROP TABLE IF EXISTS `Lang_Deutsch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Lang_Deutsch` (
  `id` int(11) NOT NULL,
  `word` varchar(500) CHARACTER SET latin1 DEFAULT NULL,
  `notes` varchar(500) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Lang_Deutsch`
--

LOCK TABLES `Lang_Deutsch` WRITE;
/*!40000 ALTER TABLE `Lang_Deutsch` DISABLE KEYS */;
INSERT INTO `Lang_Deutsch` (`id`, `word`, `notes`) VALUES (0,'Anmelden',NULL),(1,'Abmelden',NULL),(2,'Mein konto',NULL),(3,'Prana-deutschland - copyright 2016',NULL),(4,'Startseite',NULL),(5,NULL,NULL),(6,'Einloggen',NULL),(7,'Benutzername (Max. 15 Zeichen)',NULL),(8,'Vorname',NULL),(9,'Nachname',NULL),(10,'Bereich/Gegend (Berlin)',NULL),(11,'Passwort*',NULL),(12,'* = Felder mit dem Stern müssen ausgefüllt werden.',NULL),(13,'Umsonst',NULL),(14,'Geb(uml)hrenpflichtig',NULL),(15,'Art',NULL),(16,'Mein Profil',NULL),(17,'Suche',NULL),(18,'Suche Prana',NULL),(19,'Essen',NULL),(20,'Unterkunft',NULL),(21,'Ärztliche Versorgung',NULL),(22,'Rechtliche Hinweise',NULL),(23,'Bildung',NULL),(24,'Arbeit',NULL),(25,NULL,NULL),(26,'Liste',NULL),(27,'Karte',NULL),(28,'Anmelder oder einloggen',NULL),(29,'Anzeigesuche',NULL),(30,'Benutzername',NULL),(31,'Passwort',NULL),(32,'Zugangsdaten vergessen? ',NULL),(33,'Klicken Sie hier.',NULL),(34,'Prana',NULL),(35,'--',NULL),(36,'--',NULL),(37,'Filter',NULL),(38,'A-Z',NULL),(39,'Z-A',NULL),(40,'< Zurück',NULL),(41,'--',NULL),(42,'Bereich/Gegend',NULL),(43,'Geöffnet (Uhr)',NULL),(44,'--',NULL),(45,'Geöffnet (Tag)',NULL),(46,'Nach organisation',NULL),(47,'Ansehen',NULL),(48,'Infos:',NULL),(49,'Öffnungszeiten',NULL),(50,'Telefon',NULL),(51,'Emailadresse',NULL),(52,'Adresse',NULL),(53,'--',NULL),(54,'Route planen/berechnen',NULL),(55,'Gebühr',NULL),(56,'Organisation',NULL),(57,'--',NULL),(58,'Telefon',NULL),(59,'--',NULL),(60,'--',NULL),(61,'--',NULL),(62,'--',NULL),(63,'--',NULL),(64,'--',NULL),(65,'--',NULL),(66,'--',NULL),(67,'Zu',NULL),(68,'(per) Auto',NULL),(69,'Zu fuß',NULL),(70,'Fahrrad',NULL),(71,'Öffentliche Verkehrsmittel',NULL),(72,'Bus',NULL),(73,'U-bahn',NULL),(74,'Zug',NULL),(75,'Tram',NULL),(76,'Neue route',NULL),(77,'Drucken',NULL),(78,'Wegbeschreibung',NULL),(79,'Größere karte',NULL),(80,'Kleinere karte',NULL),(81,'--',NULL),(82,'Andere von dieser organisation',NULL),(83,'Montag',NULL),(84,'Dienstag',NULL),(85,'Mittwoch',NULL),(86,'Donnerstag',NULL),(87,'Freitag',NULL),(88,'Samstag',NULL),(89,'Sonntag',NULL),(90,'--',NULL),(91,'Nicht verfügbar',NULL),(92,'--',NULL),(93,'--',NULL),(94,'--',NULL),(95,'--',NULL),(96,'--',NULL),(97,'--',NULL),(98,'--',NULL),(99,'--',NULL),(100,'--',NULL),(101,'--',NULL),(102,'--',NULL),(103,'--',NULL),(104,'Geöffnet (Monat)',NULL);
/*!40000 ALTER TABLE `Lang_Deutsch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Lang_English`
--

DROP TABLE IF EXISTS `Lang_English`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Lang_English` (
  `id` int(11) NOT NULL,
  `word` varchar(500) DEFAULT NULL,
  `owner` varchar(150) DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Lang_English`
--

LOCK TABLES `Lang_English` WRITE;
/*!40000 ALTER TABLE `Lang_English` DISABLE KEYS */;
INSERT INTO `Lang_English` (`id`, `word`, `owner`, `notes`) VALUES (0,'Login','all',NULL),(1,'Logout','all',NULL),(2,'My Account','all',NULL),(3,'Prana-deutschland - copyright 2016 ','all',NULL),(4,'Home','all',NULL),(5,'Go to Login','all',NULL),(6,'Sign Up','all',NULL),(7,'User name* (Max. 15 characters)','signup',NULL),(8,'First name*','all',NULL),(9,'Last name*','all',NULL),(10,'Area (Berlin)','all',NULL),(11,'Password*','all',NULL),(12,'* = Fields with the star must be filled out.','all',NULL),(13,'Free','all',NULL),(14,'Paid','all',NULL),(15,'Type','all',NULL),(16,'My Profile','all',NULL),(17,'Search for resources','all',NULL),(18,'Search Prana','all',NULL),(19,'Food','all',NULL),(20,'Housing','all',NULL),(21,'Medical','all',NULL),(22,'Legal','all',NULL),(23,'Study','all',NULL),(24,'Jobs','all',NULL),(25,'Grid','all',NULL),(26,'List','all',NULL),(27,'Map','all',NULL),(28,'Login or Sign Up','all',NULL),(29,'Search Postings','all',NULL),(30,'Username','login',NULL),(31,'Password','all',NULL),(32,'If you forgot either both or one of your login credentials, ','all',NULL),(33,'Click Here','all',NULL),(34,'Prana','all',NULL),(35,'My prana','all',NULL),(36,'Search Bookmarks','all',NULL),(44,'to','all',NULL),(43,'Time open','all',NULL),(42,'Area','all',NULL),(37,'Filters:','all',NULL),(38,'A-Z','all',NULL),(39,'Z-A','all',NULL),(40,'< back','all',NULL),(41,'forward >','all',NULL),(45,'Day open','all',NULL),(46,'By organization','all',NULL),(47,'View','all',NULL),(48,'Info:','all',NULL),(49,'Hours open','all',NULL),(50,'Tel','all',NULL),(51,'Email','all',NULL),(52,'Address','all',NULL),(53,'0 results found','all',NULL),(54,'Plan route','all',NULL),(55,'Fee','all',NULL),(56,'Organization','all',NULL),(57,'Contact person','all',NULL),(58,'Telephone','all',NULL),(59,'Fax','all',NULL),(60,'Website','all',NULL),(62,'Days open','all',NULL),(63,'Months open','all',NULL),(64,'Filters (allows/is a)','all',NULL),(65,'Days','all',NULL),(66,'Time','all',NULL),(61,'Times open','all',NULL),(67,'To','all',NULL),(68,'Car','all',NULL),(69,'Walking','all',NULL),(70,'Bike','all',NULL),(71,'Public Transport','all',NULL),(72,'Bus','all',NULL),(73,'U-bahn','all',NULL),(74,'Train','all',NULL),(76,'New route','all',NULL),(75,'Tram','all',NULL),(77,'Print','all',NULL),(78,'Directions','all',NULL),(79,'Larger map','all',NULL),(80,'Smaller map','all',NULL),(81,'Postings','all',NULL),(82,'Other by this organization','all',NULL),(83,'Monday','all',NULL),(84,'Tuesday','all',NULL),(85,'Wednesday','all',NULL),(86,'Thursday','all',NULL),(87,'Friday','all',NULL),(88,'Saturday','all',NULL),(89,'Sunday','all',NULL),(90,'closed','all',NULL),(91,'N.A.','all',NULL),(92,'January','all',NULL),(93,'February','all',NULL),(94,'March','all',NULL),(95,'April','all',NULL),(96,'May','all',NULL),(97,'June','all',NULL),(98,'July','all',NULL),(99,'August','all',NULL),(100,'September','all',NULL),(101,'October','all',NULL),(102,'November','all',NULL),(103,'December','all',NULL),(104,'Month open','all',NULL),(105,'Venue type','all',NULL),(106,'Venue allows','all',NULL);
/*!40000 ALTER TABLE `Lang_English` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Lang_Polish`
--

DROP TABLE IF EXISTS `Lang_Polish`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Lang_Polish` (
  `id` int(11) NOT NULL DEFAULT '0',
  `word` varchar(500) DEFAULT NULL,
  `owner` varchar(150) DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Lang_Polish`
--

LOCK TABLES `Lang_Polish` WRITE;
/*!40000 ALTER TABLE `Lang_Polish` DISABLE KEYS */;
/*!40000 ALTER TABLE `Lang_Polish` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Langs`
--

DROP TABLE IF EXISTS `Langs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Langs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `text` varchar(30) DEFAULT NULL,
  `table` varchar(30) DEFAULT NULL,
  `gmaps_lang` varchar(2) DEFAULT NULL,
  `gmaps_reg` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Langs`
--

LOCK TABLES `Langs` WRITE;
/*!40000 ALTER TABLE `Langs` DISABLE KEYS */;
INSERT INTO `Langs` (`id`, `name`, `text`, `table`, `gmaps_lang`, `gmaps_reg`) VALUES (1,'English','English','Lang_English','en','gb'),(2,'Deutsch','Deutsch','Lang_Deutsch','de','de'),(3,'Polish','Polish','Lang_Polish','pl','pl');
/*!40000 ALTER TABLE `Langs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Organizations`
--

DROP TABLE IF EXISTS `Organizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Organizations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) DEFAULT NULL,
  `sub_of` int(120) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `tel` varchar(20) DEFAULT NULL,
  `eml` varchar(150) DEFAULT NULL,
  `fax` int(11) DEFAULT NULL,
  `transport_routes` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Organizations`
--

LOCK TABLES `Organizations` WRITE;
/*!40000 ALTER TABLE `Organizations` DISABLE KEYS */;
INSERT INTO `Organizations` (`id`, `name`, `sub_of`, `address`, `tel`, `eml`, `fax`, `transport_routes`) VALUES (1,'GEBEWO gGMBH',NULL,'Geibelstr. 77/78, 12305 Berlin','03070784490','Geschaeftsstelle@gebewo.de',56456,NULL),(2,'test org',NULL,'asdfg','sdfg','dfg',88,'g');
/*!40000 ALTER TABLE `Organizations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Organizations_Venues`
--

DROP TABLE IF EXISTS `Organizations_Venues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Organizations_Venues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `organization` int(11) DEFAULT NULL,
  `venue` varchar(3000) DEFAULT NULL,
  `Space` int(11) DEFAULT NULL,
  `Space_type` int(11) DEFAULT NULL,
  `pay_to_stay` varchar(25) DEFAULT 'N.A.',
  `Contact_person` varchar(35) DEFAULT NULL,
  `busroutes` varchar(15) DEFAULT NULL COMMENT 'Separated by commas',
  `stops` varchar(200) DEFAULT NULL,
  `days_open` varchar(16) DEFAULT NULL,
  `Open_month_from` varchar(20) DEFAULT NULL,
  `Open_month_to` varchar(20) DEFAULT NULL,
  `houropening` int(2) DEFAULT NULL,
  `hourclosing` int(2) DEFAULT NULL,
  `tel` varchar(20) DEFAULT NULL,
  `fax` varchar(20) DEFAULT NULL,
  `website` varchar(300) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `image_path` varchar(3000) DEFAULT NULL,
  `is_` varchar(150) DEFAULT NULL COMMENT 'divided by commas',
  `allows` varchar(150) DEFAULT NULL COMMENT 'divided by commas',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tel` (`tel`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Organizations_Venues`
--

LOCK TABLES `Organizations_Venues` WRITE;
/*!40000 ALTER TABLE `Organizations_Venues` DISABLE KEYS */;
INSERT INTO `Organizations_Venues` (`id`, `organization`, `venue`, `Space`, `Space_type`, `pay_to_stay`, `Contact_person`, `busroutes`, `stops`, `days_open`, `Open_month_from`, `Open_month_to`, `houropening`, `hourclosing`, `tel`, `fax`, `website`, `email`, `image_path`, `is_`, `allows`) VALUES (1,1,'Geibelstr. 77/78, 12305 Berlin',25,1,'There is no fee here','Mr. John Peck','M44,M9,101,X3',NULL,'1234567','January','December',11,23,'016065684584',NULL,'www.google.com','test@test.com','/Assets/Images/Web/orgs/klkl.jpg','Shelter,Winter [Shelter]',NULL),(2,1,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL),(3,1,'3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'/Assets/Images/Web/orgs/lkjlk.jpg',NULL,NULL);
/*!40000 ALTER TABLE `Organizations_Venues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Organizations_Venues_Categories`
--

DROP TABLE IF EXISTS `Organizations_Venues_Categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Organizations_Venues_Categories` (
  `id` int(11) NOT NULL,
  `variable` varchar(150) DEFAULT NULL,
  `name` varchar(150) NOT NULL DEFAULT '',
  `db_name` text,
  `owner` varchar(150) DEFAULT NULL,
  `allowis` varchar(10) DEFAULT NULL,
  `text` varchar(150) DEFAULT NULL,
  `singular_text` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Organizations_Venues_Categories`
--

LOCK TABLES `Organizations_Venues_Categories` WRITE;
/*!40000 ALTER TABLE `Organizations_Venues_Categories` DISABLE KEYS */;
INSERT INTO `Organizations_Venues_Categories` (`id`, `variable`, `name`, `db_name`, `owner`, `allowis`, `text`, `singular_text`) VALUES (1,'filters_housing_shelters','shelter','shelter','housing','is','Shelters','Shelter'),(2,'filters_housing_hostels','hostels','hostel','housing','is','Hostels','Hostel'),(3,'filters_housing_govt','Gov_house','governmenthousing','housing','is','WBS','WBS'),(4,'filters_housing_coldshelters','cold_shelters','coldshelter','housing','is','Winter [shelters]','Winter [shelter]'),(6,'filters_wo','Women_only','womenonly','universal','allows','[Women] only','[Women] only'),(7,'filters_mo','men_only','menonly','universal','allows','[Men] only','[Men] only'),(5,'filters_childrenok','child_ok','children','universal','allows','Minors (Under 18)','Minors (Under 18)'),(8,'filters_petsok','pets','pets','universal','allows','Allows animals','Animals'),(9,'filters_food_soupkitchens','soupkitchen','soupkitchen','food','is','Soup kitchens','Soup kitchen'),(10,'filters_food_tafels','tafel','tafel','food','is','Grocery distributions','Grocery distribution'),(11,'filters_smoking','smoke','smoking','universal','allows','Allows smoking','Smoking'),(12,'filters_food_giveaway','free_giveaway','free_giveaway','food','is','Free giveaways','Free giveaway'),(13,'filters_food_churchgive','churchgive','churchgive','food','is','Church distributions','Church distribution'),(14,'filters_food_foodtour','foodtour','foodtour','food','is','Food tours','Food tour'),(17,'filters_medical_check','checkup','checkup','medical','is','General checkup','General checkup'),(18,'filters_medical_emerg','emergency_rooms','emergency_rooms','medical','is','Emergency rooms','Emergency room');
/*!40000 ALTER TABLE `Organizations_Venues_Categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Organizations_Venues_Months`
--

DROP TABLE IF EXISTS `Organizations_Venues_Months`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Organizations_Venues_Months` (
  `id` int(11) NOT NULL,
  `organization` int(11) DEFAULT NULL,
  `organization_venue` int(11) DEFAULT NULL,
  `january` int(11) DEFAULT NULL,
  `febuary` int(11) DEFAULT NULL,
  `march` int(11) DEFAULT NULL,
  `april` int(11) DEFAULT NULL,
  `may` int(11) DEFAULT NULL,
  `june` int(11) DEFAULT NULL,
  `july` int(11) DEFAULT NULL,
  `august` int(11) DEFAULT NULL,
  `september` int(11) DEFAULT NULL,
  `october` int(11) DEFAULT NULL,
  `november` int(11) DEFAULT NULL,
  `december` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Organizations_Venues_Months`
--

LOCK TABLES `Organizations_Venues_Months` WRITE;
/*!40000 ALTER TABLE `Organizations_Venues_Months` DISABLE KEYS */;
INSERT INTO `Organizations_Venues_Months` (`id`, `organization`, `organization_venue`, `january`, `febuary`, `march`, `april`, `may`, `june`, `july`, `august`, `september`, `october`, `november`, `december`) VALUES (1,1,1,1,0,1,1,1,1,1,1,1,1,1,1);
/*!40000 ALTER TABLE `Organizations_Venues_Months` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Organizations_Venues_Times`
--

DROP TABLE IF EXISTS `Organizations_Venues_Times`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Organizations_Venues_Times` (
  `id` int(11) NOT NULL,
  `organization` int(11) DEFAULT NULL,
  `organization_venue` int(11) DEFAULT NULL,
  `monday` int(11) DEFAULT NULL,
  `monday_time_start` int(11) DEFAULT NULL,
  `monday_time_stop` int(11) DEFAULT NULL,
  `tuesday` int(11) DEFAULT NULL,
  `tuesday_time_start` int(11) DEFAULT NULL,
  `tuesday_time_stop` int(11) DEFAULT NULL,
  `wednesday` int(11) DEFAULT NULL,
  `wednesday_time_start` int(11) DEFAULT NULL,
  `wednesday_time_stop` int(11) DEFAULT NULL,
  `thursday` int(11) DEFAULT NULL,
  `thursday_time_start` int(11) DEFAULT NULL,
  `thursday_time_stop` int(11) DEFAULT NULL,
  `friday` int(11) DEFAULT NULL,
  `friday_time_start` int(11) DEFAULT NULL,
  `friday_time_stop` int(11) DEFAULT NULL,
  `saturday` int(11) DEFAULT NULL,
  `saturday_time_start` int(11) DEFAULT NULL,
  `saturday_time_stop` int(11) DEFAULT NULL,
  `sunday` int(11) DEFAULT NULL,
  `sunday_time_start` int(11) DEFAULT NULL,
  `sunday_time_stop` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Organizations_Venues_Times`
--

LOCK TABLES `Organizations_Venues_Times` WRITE;
/*!40000 ALTER TABLE `Organizations_Venues_Times` DISABLE KEYS */;
INSERT INTO `Organizations_Venues_Times` (`id`, `organization`, `organization_venue`, `monday`, `monday_time_start`, `monday_time_stop`, `tuesday`, `tuesday_time_start`, `tuesday_time_stop`, `wednesday`, `wednesday_time_start`, `wednesday_time_stop`, `thursday`, `thursday_time_start`, `thursday_time_stop`, `friday`, `friday_time_start`, `friday_time_stop`, `saturday`, `saturday_time_start`, `saturday_time_stop`, `sunday`, `sunday_time_start`, `sunday_time_stop`) VALUES (1,1,1,1,8,17,1,10,16,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `Organizations_Venues_Times` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `People`
--

DROP TABLE IF EXISTS `People`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `People` (
  `id` varchar(15) NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `homelessorvolunteer` varchar(20) DEFAULT NULL,
  `area` int(11) DEFAULT NULL,
  `pic` blob,
  `about` varchar(400) DEFAULT NULL,
  `gender` int(11) DEFAULT NULL,
  `POC` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `People`
--

LOCK TABLES `People` WRITE;
/*!40000 ALTER TABLE `People` DISABLE KEYS */;
INSERT INTO `People` (`id`, `name`, `homelessorvolunteer`, `area`, `pic`, `about`, `gender`, `POC`) VALUES ('hhh','Homero Habanero','Street fighter',1,NULL,'Who am I? What am I? What are you? why are you here? What is it? it is what it is. This is not fiction or fan fiction, this is fact its so facty it turns into a fiction of its own. 400 characters allowed only This is a description. Descriptions are nice though this one only allows 600 characters, oh bummer. Bet you what. you like this description. anyways I\'m testing the 600 characters. Its not to',1,'ggg');
/*!40000 ALTER TABLE `People` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Projects`
--

DROP TABLE IF EXISTS `Projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Projects` (
  `id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Projects`
--

LOCK TABLES `Projects` WRITE;
/*!40000 ALTER TABLE `Projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `Projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Ratings`
--

DROP TABLE IF EXISTS `Ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Ratings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL DEFAULT '-1',
  `user` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Ratings`
--

LOCK TABLES `Ratings` WRITE;
/*!40000 ALTER TABLE `Ratings` DISABLE KEYS */;
INSERT INTO `Ratings` (`id`, `post_id`, `rating`, `user`) VALUES (1,1,4,'hhh'),(2,1,2,NULL);
/*!40000 ALTER TABLE `Ratings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `User_Bookmarks`
--

DROP TABLE IF EXISTS `User_Bookmarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `User_Bookmarks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(15) NOT NULL,
  `post_id` int(11) NOT NULL,
  `home_type` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=196 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User_Bookmarks`
--

LOCK TABLES `User_Bookmarks` WRITE;
/*!40000 ALTER TABLE `User_Bookmarks` DISABLE KEYS */;
INSERT INTO `User_Bookmarks` (`id`, `user`, `post_id`, `home_type`) VALUES (182,'hhh',3,'housing'),(174,'hhh',1,'food'),(194,'hhh',1,'housing'),(193,'hhh',6,'housing'),(176,'hhh',2,'food'),(195,'hhh',7,'housing'),(179,'hhh',1,'medical');
/*!40000 ALTER TABLE `User_Bookmarks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Users`
--

DROP TABLE IF EXISTS `Users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Users` (
  `id` int(11) NOT NULL,
  `username` varchar(15) NOT NULL,
  `first_name` varchar(25) DEFAULT NULL,
  `last_name` varchar(25) DEFAULT NULL,
  `password` blob,
  `area` int(11) DEFAULT NULL,
  `language` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Users`
--

LOCK TABLES `Users` WRITE;
/*!40000 ALTER TABLE `Users` DISABLE KEYS */;
/*!40000 ALTER TABLE `Users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Vehichle_routes_busses`
--

DROP TABLE IF EXISTS `Vehichle_routes_busses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Vehichle_routes_busses` (
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Vehichle_routes_busses`
--

LOCK TABLES `Vehichle_routes_busses` WRITE;
/*!40000 ALTER TABLE `Vehichle_routes_busses` DISABLE KEYS */;
/*!40000 ALTER TABLE `Vehichle_routes_busses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'prndtbse'
--

--
-- Dumping routines for database 'prndtbse'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-16  8:31:04
